import React from 'react';
import {StyleSheet,Text, View} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const App=()=> (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>
       <Text style={styles.boldText}>Jason</Text>
        <Text style={styles.italicText}>Lebico</Text>
      </Text>
    </SafeAreaView>
  </SafeAreaProvider>
);
const styles =StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    backgroundColor: '#eaeaea',
    borderColor: 'black',
  },
  title:{
    marginTop: 16,
    paddingVertical: 8,
    borderWidth:'4',
    borderColor:'#20232a',
    borderRadius: 6,
    backgroundColor:"green",
    color:'white',
    textAlign:'center',
    fontSize:30,

  },
  boldText:{
    fontVariant:'bold',
  },
  italicText:{
    fontStyle:'italic',
  },
     },);
export default App;