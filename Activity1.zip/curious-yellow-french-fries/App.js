import React from 'react';
import {Text,ScrollView, View} from 'react-native';

const Activity1 =()=>{
  return(
    <ScrollView>
    <Text>
    Bakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitara Bakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitaraBakit pa kailangang magbihis?
Sayang din naman ang porma
Lagi lang namang may sisingit
Sa t'wing tayo'y magkasama
Bakit pa kailangan ng rosas
Kung marami namang mag-aalay sa 'yo?
Uupo na lang at aawit
Maghihintay ng pagkakataon
Hahayaan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Mapapagod lang sa kakatingin
Kung marami namang nakaharang
Aawit na lang at magpaparinig
Ng lahat ng aking nadarama
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Idadaan na lang sa gitara
Pagbibigyan na lang silang magkandarapa na manligaw sa 'yo
Idadaan na lang kita sa awitin kong ito
Sabay ang tugtog ng gitara
Oh-oh-oh-oh, idadaan na lang
Sa gitara
</Text>
    </ScrollView>
  );
};
export default Activity1;
