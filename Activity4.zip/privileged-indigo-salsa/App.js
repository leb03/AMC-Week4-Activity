import React from 'react';
import {View, FlatList, StyleSheet,TouchableOpacity, Text, StatusBar,ScrollView} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const Morning = [
  {
    id: '01',
    title: 'gigising',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'using phone',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'kakain',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'drawing',
  },
   {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: ' maglalaro',
  },
];
const Afternoon = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'maliligo',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'paghuhugas',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'matutulog',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'kakain',
  },
   {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: ' matutulog',
  },
];
const Evening = [
  {
    id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
    title: 'kakain',
  },
  {
    id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
    title: 'maghuhugas',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: 'maliligo',
  },
  {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: ' maglalaro',
  },
   {
    id: '58694a0f-3da1-471f-bd96-145571e29d72',
    title: ' matutulog',
  },
];

type ItemProps = {title: string};

const Item = ({title}: ItemProps) => (
  <View style={styles.item}>
  <TouchableOpacity>
    <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  </View>
);

const App = () => (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container}>
    <ScrollView>
    <text>Morning</text>
      <FlatList
        data={Morning}
        renderItem={({item}) => <Item title={item.title} />}
        keyExtractor={item => item.id}
      />
      <text>Afternoon</text>
      <FlatList
        data={Afternoon}
        renderItem={({item}) => <Item title={item.title} />}
        keyExtractor={item => item.id}
      />
      <text>Evening</text>
      <FlatList
        data={Evening}
        renderItem={({item}) => <Item title={item.title} />}
        keyExtractor={item => item.id}
        />
      </ScrollView>
    </SafeAreaView>
  </SafeAreaProvider>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  title: {
    fontSize: 32,
  },
});

export default App;